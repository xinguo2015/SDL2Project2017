/*
showfont:  An example of using the SDL_ttf library with 2D graphics.
Copyright (C) 2001-2016 Sam Lantinga <slouken@libsdl.org>

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
claim that you wrote the original software. If you use this software
in a product, an acknowledgment in the product documentation would be
appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/

/* A simple program to test the text rendering feature of the TTF library */

/* quiet windows compiler warnings */
#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "SDL.h"
#include "SDL_ttf.h"


SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;
SDL_Texture *textTexture = NULL;

SDL_Texture * genMsgTexture(char msg[], char fontfile[], int fontsize, SDL_Color fgcolor)
{
	TTF_Font *font = NULL;
	SDL_Surface* surface = NULL;
	SDL_Texture* texResult = NULL;
	font = TTF_OpenFont(fontfile, fontsize);//������
	surface = TTF_RenderText_Blended(font, msg, fgcolor);
	if( surface ) texResult = SDL_CreateTextureFromSurface(renderer,surface);//������������
	SDL_FreeSurface(surface); //�ͷ�surface
	TTF_CloseFont(font);//�ر������ļ�
	return texResult;
}

void DrawMessage()
{
	SDL_Rect rect = { 0, 0, 0, 0 };
	SDL_Color fgcolor = {0xFF, 0x00, 0xFF, 0xFF};
	SDL_Texture * msgtex = genMsgTexture("Hello world",
		"C:\\Windows\\Fonts\\arial.ttf", //�����ļ�
		46, //�����С
		fgcolor); //��ʾ����ɫ
	if( !msgtex ) return;
	SDL_QueryTexture(msgtex,NULL,NULL, &rect.w, &rect.h);
	SDL_RenderCopy(renderer, msgtex, NULL, &rect);
	SDL_DestroyTexture(msgtex);
}

int main(int argc, char *argv[]) 
{
	int posX = 100, posY = 100, width = 640, height = 480;

	SDL_Init(SDL_INIT_VIDEO);

	window = SDL_CreateWindow("Demo text drawing in SDL", posX, posY, width, height, 0);

	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x80, 0xFF );

	// Initialize TTF
	if ( TTF_Init() < 0 ) {
		printf("Couldn't initialize TTF: %s\n",SDL_GetError());
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return (-1);
	}
	// Display image texture
	SDL_RenderClear(renderer);
	DrawMessage();
	SDL_RenderPresent(renderer);
	// Enter event processing loop 
	while ( 1 ) {
		SDL_Event e;
		if (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT) {
				break;
			}
		}
	}
	// Destroy and quit
	TTF_Quit();
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;
}