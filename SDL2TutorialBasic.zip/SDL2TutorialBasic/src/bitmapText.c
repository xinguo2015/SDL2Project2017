#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "SDL_ttf.h"
#include "bitmapFont.h"

BitmapFont     gBitmapFont;
SDL_Window *   gMainWindow = NULL;
SDL_Renderer * gMainRenderer = NULL;
SDL_Rect       gMainWinRect = { 100, 100, 640, 480 };

void initApp(int argc, char *argv[])
{
	SDL_Init(SDL_INIT_VIDEO);
	// ��������
	if( ! (gMainWindow = SDL_CreateWindow(argv[0], gMainWinRect.x, gMainWinRect.y, gMainWinRect.w, gMainWinRect.h, 0) ) ) {
		printf("Error create SDL window\n");
		exit(-1);
	}
	// �������ƻ���
	if( ! (gMainRenderer = SDL_CreateRenderer(gMainWindow, -1, SDL_RENDERER_ACCELERATED)) ) {
		printf("Error create SDL Renderer\n");
		SDL_DestroyWindow(gMainWindow);
		SDL_Quit();
		exit(-1);
	}
	// ��ʼ�� bitmap fontʹ��
	if ( ! createBitmapFont( gMainRenderer, "media\\fonts\\simhei.bmp", &gBitmapFont ) ) {
		SDL_DestroyRenderer(gMainRenderer);
		SDL_DestroyWindow(gMainWindow);
		SDL_Quit();
		exit(-1);
	}
}

void endApp()
{

	cleanBitmapFont( &gBitmapFont );
	SDL_DestroyRenderer(gMainRenderer);
	SDL_DestroyWindow(gMainWindow);
	SDL_Quit();
}

void handleEvent(SDL_Event * e);
void display();

int main(int argc, char *argv[]) 
{
	initApp(argc,argv);
	// Enter event processing loop 
	while ( 1 ) 
	{
		SDL_Event e;
		if (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT) {
				break; // ��ֹӦ�ó���
			}
			handleEvent( &e );
		}
		display();
	}
	endApp();

	return 0;
}

void display()
{
	int x = 50, y = 100, h = -1;
	SDL_SetRenderDrawColor(gMainRenderer, 0xC0,0xC0,0xC0,0xFF);
	//SDL_SetRenderDrawColor(gMainRenderer, 0,0,0,255);
	SDL_RenderClear(gMainRenderer);
	// draw rectangle
	SDL_SetRenderDrawBlendMode(gMainRenderer, SDL_BLENDMODE_MOD);
	x += renderChar(gMainRenderer,&gBitmapFont, x, y, h, 'h');
	x += renderChar(gMainRenderer,&gBitmapFont, x, y, h, 'H');
	x += renderChar(gMainRenderer,&gBitmapFont, x, y, h, ' ');
	x += renderChar(gMainRenderer,&gBitmapFont, x, y, h, 'e');
	// present the result
	SDL_RenderPresent(gMainRenderer);
}

void handleEvent(SDL_Event* e)
{
	switch( e->type )
	{ 
	case SDL_MOUSEBUTTONDOWN: // mouse button down event
		break;
	case SDL_MOUSEBUTTONUP: // mouse button down event
		break;
	case SDL_MOUSEMOTION: // mouse button down event
		break;
	case SDL_KEYDOWN:
		break;
		break;  
	default:
		break;
	}
}