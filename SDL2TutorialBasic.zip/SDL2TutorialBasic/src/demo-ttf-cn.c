/*
showfont:  An example of using the SDL_ttf library with 2D graphics.
Copyright (C) 2001-2016 Sam Lantinga <slouken@libsdl.org>

This software is provided 'as-is', without any express or implied
warranty.  In no event will the authors be held liable for any damages
arising from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
claim that you wrote the original software. If you use this software
in a product, an acknowledgment in the product documentation would be
appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
misrepresented as being the original software.
3. This notice may not be removed or altered from any source distribution.
*/

/* A simple program to test the text rendering feature of the TTF library */

/* quiet windows compiler warnings */
#define _CRT_SECURE_NO_WARNINGS

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <windows.h>

#include "SDL.h"
#include "SDL_ttf.h"

char* localeToUTF8(char src[],char result[])
{
    int nRetLen = MultiByteToWideChar(CP_ACP,0,src,-1,NULL,0);
    wchar_t *unicode_buf = (wchar_t*)malloc((nRetLen+1)*sizeof(wchar_t));
    MultiByteToWideChar(CP_ACP,0,src,-1,unicode_buf,nRetLen);
    nRetLen = WideCharToMultiByte(CP_UTF8,0,unicode_buf,-1,NULL,0,NULL,NULL);
    WideCharToMultiByte(CP_UTF8,0,unicode_buf,-1,result,nRetLen,NULL,NULL);
    free(unicode_buf);
    return result;
}

wchar_t* strToUnicode(char src[], wchar_t result[])
{
    int size;
    if( !src ) return NULL;
	size=MultiByteToWideChar(CP_ACP,0,src,-1,NULL,0);
    MultiByteToWideChar(CP_ACP,0,src,-1,result,size);
    return result;
}

SDL_Window *window = NULL;
SDL_Renderer *renderer = NULL;
SDL_Texture *textTexture = NULL;

SDL_Texture * genUnicodeMsgTexture(char msg[], char fontfile[], int fontsize, SDL_Color fgcolor)
{
	TTF_Font *font = NULL;
	SDL_Surface* surface = NULL;
	SDL_Texture* texResult = NULL;
	font = TTF_OpenFont(fontfile, fontsize);//������
	surface = TTF_RenderUNICODE_Blended(font,(Uint16*)msg,fgcolor);
	if( surface ) texResult = SDL_CreateTextureFromSurface(renderer,surface);//������������
	SDL_FreeSurface(surface); //�ͷ�surface
	TTF_CloseFont(font);//�ر������ļ�
	return texResult;
}

void DrawChineseMessage()
{
	SDL_Rect rect = { 0, 0, 0, 0 };
	SDL_Color fgcolor = {0xFF, 0x00, 0xFF, 0xFF};
	SDL_Texture * msgtex = NULL;
	wchar_t buf[256];
	if( !(msgtex = genUnicodeMsgTexture((char*)strToUnicode("��� Hello World",buf), 
		"C:\\Windows\\Fonts\\simfang.ttf", //ѡ������
		46, fgcolor)) )
		return;
	SDL_QueryTexture(msgtex,NULL,NULL, &rect.w, &rect.h);
	SDL_RenderCopy(renderer, msgtex, NULL, &rect);
	SDL_DestroyTexture(msgtex);
	// �ٻ���һ������
	if( !(msgtex = genUnicodeMsgTexture((char*)buf, 
		"C:\\Windows\\Fonts\\simhei.ttf", //ѡ�ú���
		66,  // ��������ߴ�
		fgcolor)) )
		return;
	rect.y = rect.h; // ��������ʾλ���Ƶ�����
	SDL_QueryTexture(msgtex,NULL,NULL, &rect.w, &rect.h);
	SDL_RenderCopy(renderer, msgtex, NULL, &rect);
	SDL_DestroyTexture(msgtex);
}

int main(int argc, char *argv[]) 
{
	int posX = 100, posY = 100, width = 640, height = 480;
	char buf[256];

	SDL_Init(SDL_INIT_VIDEO);

	//window = SDL_CreateWindow("True Type Fonts", posX, posY, width, height, 0);
	window = SDL_CreateWindow(localeToUTF8("��ʾ�����SDL����ʾ����",buf), posX, posY, width, height, 0);

	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
	SDL_SetRenderDrawColor(renderer, 0x00, 0x00, 0x80, 0xFF );

	// Initialize TTF
	if ( TTF_Init() < 0 ) {
		printf("Couldn't initialize TTF: %s\n",SDL_GetError());
		SDL_DestroyRenderer(renderer);
		SDL_DestroyWindow(window);
		SDL_Quit();
		return (-1);
	}
	// Display image texture
	SDL_RenderClear(renderer);
	DrawChineseMessage();
	SDL_RenderPresent(renderer);
	// Enter event processing loop 
	while ( 1 ) {
		SDL_Event e;
		if (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT) {
				break;
			}
		}
	}
	// Destroy and quit
	TTF_Quit();
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);
	SDL_Quit();

	return 0;
}