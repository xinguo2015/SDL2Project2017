#include "SDL.h"

typedef struct {
	SDL_Rect  rect;
	char      label[128];
	int       isClicked;
	SDL_Color labelColor;
} Button;

void drawButton(Button *b);
int pointOnButton(int x, int y, Button *b);
