#include <stdio.h>
#include "SDL.h"

void handleEvent(SDL_Event* e);

int main(int argc, char *argv[]) 
{
	SDL_Window *win = NULL;
	SDL_Renderer *renderer = NULL;
	int posX = 100, posY = 100, width = 640, height = 480;

	SDL_Init(SDL_INIT_VIDEO);

	win = SDL_CreateWindow("Hello World", posX, posY, width, height, 0);

	renderer = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

	// Display image texture
	SDL_RenderClear(renderer);
	SDL_RenderPresent(renderer);
	// Enter event processing loop 
	while ( 1 ) {
		SDL_Event e;
		if (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT) {
				break; // ��ֹӦ�ó���
			}
			// processing other type of event
			handleEvent( &e );
		}
	}
	// Destroy and quit
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(win);
	SDL_Quit();

	return 0;
}


void handleEvent(SDL_Event* e)
{
	switch (e->type) {
	case SDL_TEXTEDITING:
		if( e->edit.text[0] )printf("text edit = %s\n", e->edit.text);
		else printf("text edit is NULL\n");
		break;
	case SDL_TEXTINPUT:
		if( e->text.text[0] )printf("text input = %s\n", e->text.text);
		else printf("text input is NULL\n");
		break;
	case SDL_KEYDOWN:
		break;
	case SDL_KEYUP:
		switch (e->key.keysym.sym) {
		case SDLK_ESCAPE: 
			{
				SDL_Event ev;
				ev.type = SDL_QUIT; 
				SDL_PushEvent( &ev );
			}
		}
		break;
	default:
		break;
	}
}