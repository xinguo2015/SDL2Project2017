#ifndef ___bit_map_font_h_________
#define ___bit_map_font_h_________

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "SDL.h"

typedef struct {
	int width, height;
	int offset[128];
	SDL_Texture * tex;
} BitmapFont;

int createBitmapFont(SDL_Renderer * renderer, char fontFile[], BitmapFont * font);
int cleanBitmapFont(BitmapFont * font);
int renderChar(SDL_Renderer * renderer, BitmapFont * font, int x, int y, int height, char ch);

#endif //#define ___bit_map_font_h_________