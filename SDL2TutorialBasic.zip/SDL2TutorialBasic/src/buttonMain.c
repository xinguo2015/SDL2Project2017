#include <stdlib.h>
#include <stdio.h>
#include "SDL.h"
#include "SDL_ttf.h"

#include "button.h"

SDL_Window *   gMainWindow = NULL;
SDL_Renderer * gMainRenderer = NULL;
SDL_Rect       gMainWinRect = { 100, 100, 640, 480 };

Button clickButton = { { 200, 100, 200, 40 }, "Try Clicking Me",  0, {0,255,255,255} };
Button quitButton =  { { 200, 250, 200, 40 }, "Click me to quit", 0, {255,0,0,255} };
Button editButton =  { { 200, 400, 200, 40 }, "Click me to edit", 0, {255,255,255,255} };

void initApp(int argc, char *argv[])
{
	SDL_Init(SDL_INIT_VIDEO);
	// ��������
	if( ! (gMainWindow = SDL_CreateWindow(argv[0], gMainWinRect.x, gMainWinRect.y, gMainWinRect.w, gMainWinRect.h, 0) ) ) {
		printf("Error create SDL window\n");
		exit(-1);
	}
	// �������ƻ���
	if( ! (gMainRenderer = SDL_CreateRenderer(gMainWindow, -1, SDL_RENDERER_ACCELERATED)) ) {
		printf("Error create SDL Renderer\n");
		SDL_DestroyWindow(gMainWindow);
		SDL_Quit();
		exit(-1);
	}
	// ��ʼ�� true type fontʹ��
	if ( TTF_Init() < 0 ) {
		printf("Couldn't initialize TTF: %s\n",SDL_GetError());
		SDL_DestroyRenderer(gMainRenderer);
		SDL_DestroyWindow(gMainWindow);
		SDL_Quit();
		exit(-1);
	}
}

void endApp()
{
	TTF_Quit();
	SDL_DestroyRenderer(gMainRenderer);
	SDL_DestroyWindow(gMainWindow);
	SDL_Quit();
}

void handleEvent(SDL_Event * e);
void display();

int main(int argc, char *argv[]) 
{
	initApp(argc,argv);
	// Enter event processing loop 
	while ( 1 ) 
	{
		SDL_Event e;
		if (SDL_PollEvent(&e)) {
			if (e.type == SDL_QUIT) {
				break; // ��ֹӦ�ó���
			}
			handleEvent( &e );
		}
		display();
	}
	endApp();

	return 0;
}

void display()
{
	SDL_SetRenderDrawColor(gMainRenderer, 0xC0,0xC0,0xC0,0xFF);
	//SDL_SetRenderDrawColor(gMainRenderer, 0,0,0,255);
	SDL_RenderClear(gMainRenderer);
	// draw rectangle
	drawButton(&clickButton);
	drawButton(&quitButton);
	drawButton(&editButton);
	// present the result
	SDL_RenderPresent(gMainRenderer);
}
static void  
PrintText(char *text)  
{  
    char *spot, expanded[1024];  
  
    expanded[0] = '\0';  
    for (spot = text; *spot; ++spot)  
    {   
        //��ʽ��  
        size_t length = SDL_strlen(expanded);  
        //���ַ�����ʽ����buffer  
        SDL_snprintf(expanded + length, sizeof(expanded) - length, "\\x%.2x", (unsigned char)*spot);  
    }  
    //��ӡ��־   
    SDL_Log("Text (%s): \"%s%s\"\n", expanded, *text == '"' ? "\\" : "", text);  
}  

void handleEvent(SDL_Event* e)
{
	switch( e->type )
	{ 
	case SDL_MOUSEBUTTONDOWN: // mouse button down event
		if( pointOnButton(e->button.x, e->button.y, &clickButton) )
			clickButton.isClicked = 1;
		else if( pointOnButton(e->button.x, e->button.y, &quitButton) )
			quitButton.isClicked = 1;
		break;
	case SDL_MOUSEBUTTONUP: // mouse button down event
		clickButton.isClicked = 0;
		quitButton.isClicked = 0;
		if( pointOnButton(e->button.x, e->button.y, &quitButton) )
		{
			SDL_Event ev;
			ev.type = SDL_QUIT; 
			SDL_PushEvent( &ev );
		}
		break;
	case SDL_MOUSEMOTION: // mouse button down event
		break;
	case SDL_KEYDOWN:
		break;
	case SDL_TEXTINPUT:
		//������ı����� ����ı�  
		PrintText(e->text.text);  
		break;  
	default:
		break;
	}
}