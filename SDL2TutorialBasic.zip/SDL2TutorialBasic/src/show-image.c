#include "SDL.h"

int main(int argc, char *argv[]) 
{
	SDL_Window *win = NULL;
	SDL_Renderer *renderer = NULL;
	SDL_Texture *bitmapTexture = NULL;
	SDL_Surface *bitmapSurface = NULL;
	int posX = 100, posY = 100, width = 640, height = 480;

	SDL_Init(SDL_INIT_VIDEO);

	win = SDL_CreateWindow("Hello World", posX, posY, width, height, 0);

	renderer = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED);

	// Load an image
	bitmapSurface = SDL_LoadBMP("media/background.bmp");
	// Convert to image texture
	bitmapTexture = SDL_CreateTextureFromSurface(renderer, bitmapSurface);
	SDL_FreeSurface(bitmapSurface); // free the image
	// Display image texture
	SDL_RenderClear(renderer);
	SDL_RenderCopy(renderer, bitmapTexture, NULL, NULL);
	SDL_RenderPresent(renderer);
	// Pause execution for 3 seconds
	SDL_Delay(3000);
	// Destroy and quit
	SDL_DestroyTexture(bitmapTexture);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(win);
	SDL_Quit();

	return 0;
}