#include <stdlib.h>
#include <stdio.h>
#include "button.h"
#include "SDL_ttf.h"

extern SDL_Window *   gMainWindow;
extern SDL_Renderer * gMainRenderer;
extern SDL_Rect       gMainWinRect;

int pointOnButton(int x, int y, Button *b)
{
	return( x > b->rect.x && x < b->rect.x + b->rect.w &&
		    y > b->rect.y && y < b->rect.y + b->rect.h );
}

static void DrawBumpRect(int x1, int y1, int x2, int y2, int thick, int dark, int bright)
{
	int k;
	for( k=0; k<thick; k++ )
	{ 
		SDL_SetRenderDrawColor( gMainRenderer, dark, dark, dark, 0xFF );        
		SDL_RenderDrawLine( gMainRenderer, x1+k, y1+k, x2-k, y1+k);
		SDL_RenderDrawLine( gMainRenderer, x1+k, y1+k, x1+k, y2-k);
		SDL_SetRenderDrawColor( gMainRenderer, bright, bright, bright, 0xFF );        
		SDL_RenderDrawLine( gMainRenderer, x1+k, y2-k, x2-k, y2-k);
		SDL_RenderDrawLine( gMainRenderer, x2-k, y1+k, x2-k, y2-k);  
	}
}

static SDL_Texture * genMsgTexture(char msg[], char fontfile[], int fontsize, SDL_Color fgcolor)
{
	TTF_Font *font = NULL;
	SDL_Surface* surface = NULL;
	SDL_Texture* texResult = NULL;
	font = TTF_OpenFont(fontfile, fontsize);//������
	surface = TTF_RenderText_Blended(font, msg, fgcolor);
	if( surface ) texResult = SDL_CreateTextureFromSurface(gMainRenderer,surface);//������������
	SDL_FreeSurface(surface); //�ͷ�surface
	TTF_CloseFont(font);//�ر������ļ�
	return texResult;
}

void drawButton(Button *b)
{	
	int dark = 130, bright = 250;
	SDL_Texture *textTex = genMsgTexture(b->label, "C:\\Windows\\Fonts\\arial.ttf",20, b->labelColor);
	if( b->isClicked ) {
		DrawBumpRect(b->rect.x, b->rect.y, b->rect.x+b->rect.w, 
			b->rect.y+b->rect.h, 3, dark, bright);
	} else {
		DrawBumpRect(b->rect.x, b->rect.y, b->rect.x+b->rect.w, 
			b->rect.y+b->rect.h, 3, bright, dark);
	}
	if( textTex ) {
		SDL_Rect texRect;
		SDL_QueryTexture(textTex, NULL, NULL, &texRect.w, &texRect.h);
		texRect.x = b->rect.x + b->rect.w/2-texRect.w/2; 
		texRect.y = b->rect.y + b->rect.h/2-texRect.h/2;
		SDL_RenderCopy(gMainRenderer, textTex, NULL, &texRect);
		SDL_DestroyTexture(textTex);
	}
}


