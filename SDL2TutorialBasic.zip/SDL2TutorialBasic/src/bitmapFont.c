#include "bitmapFont.h"

static int calcFontOffset(SDL_Surface * surf, int offset[])
{
	int w, h, k, pitch, rowPerChar, bytePerPixel;
	unsigned char *p;

	if (SDL_MUSTLOCK(surf)) 
		if (SDL_LockSurface(surf) < 0) 
			return 0;
	w = surf->w;
	h = surf->h;
	p = (unsigned char*)surf->pixels;
	pitch = surf->pitch;
	bytePerPixel = surf->format->BytesPerPixel;
	rowPerChar = h/128;

	for( k=0; k<128; k++ )
		offset[k] = w/2;
	for ( k=0; k<h; k++, p += pitch ) {
		int ch = k/rowPerChar, x;
		// check k-the row, to find non zero value
		for( x=0; x<w/2; x++ ) {
			if( p[3*x] || p[3*x+1] || p[3*x+2] || p[3*(w-1-x)] 
				|| p[3*(w-1-x)+1] || p[3*(w-1-x)+2] ) {
				if( x<offset[ch] ) 
					offset[ch] = x;
				break;
			}
		}		
	}
	for( k=0; k<128; k++ ) {
		if( offset[k] == w/2 ) offset[k] = w/4;
		else offset[k] -= 2;
		if( offset[k]<0 ) offset[k] = 0;
	}
	if (SDL_MUSTLOCK(surf))
		 SDL_UnlockSurface(surf);
	return 1;
}

int createBitmapFont(SDL_Renderer * renderer, char fontFile[], BitmapFont * font)
{
	SDL_Texture * tex;
	SDL_Surface * surf;
	if( !(surf = SDL_LoadBMP(fontFile) ) ) return 0;
	if( !(tex = SDL_CreateTextureFromSurface(renderer,surf) ) ) return 0;
	font->tex = tex;
	font->width = surf->w;
	font->height = surf->h/128;
	calcFontOffset(surf,font->offset);
	SDL_FreeSurface(surf);
	return 1;
}

int cleanBitmapFont(BitmapFont * font)
{
	SDL_DestroyTexture(font->tex);
	memset(font,0,sizeof(BitmapFont));
	return 1;
}

int renderChar(SDL_Renderer* renderer, BitmapFont * font, int x, int y, int vsize, char ch)
{
	int w, h; 
	if( !renderer || !font ) return 0;
	w = font->width - font->offset[ch]*2;
	h = font->height;
	if( vsize>0 ) {
		w = (int)(vsize/(float)h*w);
		h = vsize;
	}
	{
		SDL_Rect s = {font->offset[ch], font->height*ch, font->width - font->offset[ch]*2, font->height};
		SDL_Rect t = {x,y,w,h};
		SDL_RenderCopy(renderer, font->tex, &s, &t);
	}
	return w;
}

